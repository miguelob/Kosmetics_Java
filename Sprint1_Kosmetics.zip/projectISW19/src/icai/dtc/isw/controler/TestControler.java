package icai.dtc.isw.controler;

import java.util.ArrayList;

import icai.dtc.isw.dao.TestDAO;
import icai.dtc.isw.domain.Test;

public class TestControler{

	public void getTests(ArrayList<Test> lista) {
		TestDAO.getTests(lista);
	}	
}
