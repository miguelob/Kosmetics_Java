package icai.dtc.isw.gui;
import java.awt.Font;
import java.awt.Color;

public class GUIConstants {
	
	  public static final Font FONT_REGULAR = new Font("Font.SERIF_MD", Font.PLAIN, 16);
	  public static final Font FONT_REGULAR_BOLD = new Font("Font.SERIF_MD", Font.BOLD, 16);
	  /**Fuente para t�tulos de la interfaz gr�fica, en este caso "SERIF_MD", en negrita y de tamano 20
	  */
	  public static final Font FONT_TITLE = new Font("Font.SERIF_MD", Font.BOLD, 20);
	  /**Fuente para t�tulos principales de la interfaz gr�fica, en este caso "SERIF_MD", en negrita y de tamano 20
	  */
	  public static final Font FONT_MEDIUM_TITLE = new Font("Font.SERIF_MD", Font.BOLD, 40);
	  public static final Font FONT_BIG_TITLE = new Font("Font.SERIF_MD", Font.BOLD, 60);
	  
	  public static final Color DEFAULT_FONT_COLOR = new Color(80, 80, 80);

}
