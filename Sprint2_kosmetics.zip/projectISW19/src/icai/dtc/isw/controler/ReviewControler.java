package icai.dtc.isw.controler;

import java.util.ArrayList;

import icai.dtc.isw.dao.ReviewDAO;
import icai.dtc.isw.domain.Review;


public class ReviewControler {
	public void getReview(ArrayList<Review> lista) {
		ReviewDAO.getReview(lista);
	}
}
